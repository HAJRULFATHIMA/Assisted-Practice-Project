package Assisted.practice;
import java.util.*;
import java.util.Scanner;

public class Calc{
	int a;	int b;	int c;	int d;	int e; int f; int g; int h;
	public void add()
    {	
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter n1: ");
		a= sc.nextInt();
		System.out.println("Enter n2: ");
		b= sc.nextInt();
		System.out.println("sum of "+a+" and "+b+" is : "+(a+b));
    }
    public void sub() 
    {	
    	Scanner sc = new Scanner(System.in);
		System.out.println("Enter n1: ");
		c= sc.nextInt();
		System.out.println("Enter n2: ");
		d= sc.nextInt();
        System.out.println("diff of "+c+" and "+d+" is : "+(c-d));
    }
    public void mul()
    {	
    	Scanner sc = new Scanner(System.in);
		System.out.println("Enter n1: ");
		e= sc.nextInt();
		System.out.println("Enter n2: ");
		f= sc.nextInt();
        System.out.println("multiplication of "+e+" and "+f+" is : "+(e*f));
    }
    public void div() 
    {	
    	Scanner sc = new Scanner(System.in);
		System.out.println("Enter n1: ");
		g= sc.nextInt();
		System.out.println("Enter n2: ");
		h= sc.nextInt();
		if(h == 0)
        {
        	System.out.println("division of "+g+" and "+h+" is : infinite");
        }
		else
        {float i;
        float j=(float)g;
        float k=(float)h;
        i=j/k;
			System.out.println("division of "+g+" and "+h+" is : "+i);
        }
        
        
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calc x = new Calc();
		System.out.print("The operations are :\n 1.add \n 2.sub \n 3.mul \n 4.div ");
		Scanner sc= new Scanner(System.in);  
		System.out.print("\n Enter Operation to be performed: ");  
		String str= sc.nextLine();                
		
		switch (str) {
		  case "add" :
		    x.add();
		    break;
		  case "sub":
			  x.sub();
		    break;
		  case "mul":
			  x.mul();
			    break;
		  case "div":
			  x.div();
			    break;
		  default:
		    System.out.println("invalid operator");
		}
	}


}

