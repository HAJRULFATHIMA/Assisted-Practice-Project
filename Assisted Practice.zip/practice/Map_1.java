package Assisted.practice;

    import java.util.*;
	public class Map_1 {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			HashMap<Integer,String> h=new HashMap<Integer,String>();      
		      h.put(1,"Hajrul");    
		      h.put(2,"Fathima");    
		      h.put(3,"Andrew");   
		      h.put(4,"Tom"); 
		       
		      System.out.println("\nThe elements of Hashmap are ");  
		      for(Map.Entry m:h.entrySet()){    
		       System.out.println(m.getKey()+"  "+m.getValue());   
		      }
		       Hashtable<Integer,String> t=new Hashtable<Integer,String>();  
		       
	       		t.put(8,"Rose");
			      t.put(5,"Rosy");  
			      t.put(6,"Jack");  
			      t.put(7,"John");  

			      System.out.println("\nThe elements of HashTable are ");  
			      for(Map.Entry n:t.entrySet()){    
			       System.out.println(n.getKey()+" "+n.getValue()); 
			      }
			       TreeMap<Integer,String> a=new TreeMap<Integer,String>();    
				      a.put(11,"Annie");    
				      a.put(9,"Carlotte");    
				      a.put(10,"Catie");       
				      
				      System.out.println("\nThe elements of TreeMap are ");  
				      for(Map.Entry l:a.entrySet()){    
				       System.out.println(l.getKey()+" "+l.getValue());    
				      }    


		}}