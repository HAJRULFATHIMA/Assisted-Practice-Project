package Assisted.practice;

public class Inner_cls {
	
	
		 private String msg="Welcome to Java"; 
			 
			 class Inner{  
			  void hello()
		{System.out.println(msg+", Let us start learning Inner Classes");}  
			 }  

			public static void main(String[] args) {
				// TODO Auto-generated method stub
				Inner_cls obj=new Inner_cls();
				Inner_cls.Inner in=obj.new Inner();  
				in.hello();  

			}

		}

	