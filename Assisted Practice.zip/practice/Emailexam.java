package Assisted.practice;
import java.util.regex.*;
import java.util.*;
import java.util.Scanner;

public class Emailexam {
	static boolean check(String email) {
	      String regex = "[a-zA-z0-9!#$%^&*/./-]+[@][a-z]+[/.][a-z]{2,3}";
	      return email.matches(regex);
	   }
	   public static void main(String[] args) {
		  System.out.println("Enter your email id ");
	      Scanner a = new Scanner(System.in);
	      String e = a.nextLine();
	      
	      System.out.println("The E-mail ID is: " + e);
	      System.out.println("Is the above E-mail ID valid? " + check(e));
	   }
	}


	
	
	

	