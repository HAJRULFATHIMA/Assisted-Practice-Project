package Assisted_project_2;

public class O_en {
	private String name;
	private int age;
	private float salr;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public float getSalr() {
		return salr;
	}

	public void setSalr(float salr) {
		this.salr = salr;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	O_en obj = new O_en(); 
        obj.setName("HAJRUL"); 
        obj.setAge(21); 
        obj.setSalr(51000); 
        System.out.println("My name: " + obj.getName()); 
        System.out.println("My age: " + obj.getAge()); 
        System.out.println("My Salary: " + obj.getSalr());      

	}

}
