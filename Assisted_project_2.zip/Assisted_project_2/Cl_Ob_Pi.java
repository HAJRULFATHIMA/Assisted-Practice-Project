package Assisted_project_2;

public class Cl_Ob_Pi {

	String name; 
    String breed; 
    int age; 
    String color; 
    public Cl_Ob_Pi(String name, String breed, int age, String color) 
    { 
        this.name = name; 
        this.breed = breed; 
        this.age = age; 
        this.color = color; 
    } 
    public String getName() 
    { 
        return name; 
    } 
    public String getBreed() 
    { 
        return breed; 
    } 
    public int getAge() 
    { 
        return age; 
    } 
    public String getColor() 
    { 
        return color; 
    } 
    @Override
    public String toString() 
    { 
        return("Hi my name is "+ this.getName()+ ".\nMy breed,age and color are " + this.getBreed()+", " + this.getAge()+ ", and "+ this.getColor() + "."); 
    } 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Cl_Ob_Pi scott = new Cl_Ob_Pi("TOMMY","PUG", 15, "BROWN"); 
        System.out.println(scott.toString()); 

	}

}

